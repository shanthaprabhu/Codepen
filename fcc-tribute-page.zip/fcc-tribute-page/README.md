# FCC: Tribute Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/shanthaaprabhu/pen/RwRyxzw](https://codepen.io/shanthaaprabhu/pen/RwRyxzw).

