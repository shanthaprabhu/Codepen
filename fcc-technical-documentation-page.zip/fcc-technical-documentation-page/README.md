# FCC: Technical Documentation Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/shanthaaprabhu/pen/OJXeewO](https://codepen.io/shanthaaprabhu/pen/OJXeewO).

