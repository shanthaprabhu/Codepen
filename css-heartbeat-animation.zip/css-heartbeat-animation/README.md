# CSS Heartbeat Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/shanthaaprabhu/pen/WNxqMaj](https://codepen.io/shanthaaprabhu/pen/WNxqMaj).

